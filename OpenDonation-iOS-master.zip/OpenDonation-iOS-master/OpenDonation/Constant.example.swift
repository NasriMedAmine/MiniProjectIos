//
//  Constant.swift
//  OpenDonation
//
//  Created by Simon Loffler on 20/10/18.
//  Copyright © 2018 Simon Loffler. All rights reserved.
//

import Foundation

struct API {
    struct Square {
        static let API_CLIENT_ID = "your-id"
    }
}
