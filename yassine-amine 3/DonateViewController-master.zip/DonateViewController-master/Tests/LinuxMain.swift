import XCTest

import DonateViewControllerTests

var tests = [XCTestCaseEntry]()
tests += DonateViewControllerTests.allTests()
XCTMain(tests)
